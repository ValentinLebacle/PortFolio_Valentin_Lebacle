
<h1>Connexion</h1>

Mon adresse électronique : <?= getMailULoggedOn() ?> <br />

<hr>

<a href="./?action=deconnexion">se deconnecter</a>
